package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import net.sf.json.JSONArray;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity extends AppCompatActivity {
    Button bt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt1=findViewById(R.id.id1);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Users users=new Users("jamesnm2015@163.com","12456");
                try {
                    Log.d("ManAcitivity","登录状态为："+users.Login());
                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.d("MainAcitvity",e.toString());
                } catch (IOException e) {
                    Log.d("MainAcitvity",e.toString());
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    Log.d("MainAcitvity",e.toString());
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    Log.d("MainAcitvity",e.toString());
                    e.printStackTrace();
                }
            }
        });


    }
}
